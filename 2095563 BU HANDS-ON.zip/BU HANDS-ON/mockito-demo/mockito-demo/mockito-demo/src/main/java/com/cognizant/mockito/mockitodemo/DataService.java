package com.cognizant.mockito.mockitodemo;
interface DataService{
	int[] retrieveAllData();
}
